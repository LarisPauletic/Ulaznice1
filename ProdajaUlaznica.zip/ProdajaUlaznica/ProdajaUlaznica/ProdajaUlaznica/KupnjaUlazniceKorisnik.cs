﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProdajaUlaznica
{
    class KupnjaUlazniceKorisnik
    {
        int ID;
        string Ime, Prezime, Sektor, DatumRodenja;
        


        public KupnjaUlazniceKorisnik(int iD, string ime, string prezime, string sektor, string datumrodenja)
        {
            ID = iD;
            Ime = ime;
            Prezime = prezime;
            Sektor = sektor;
            DatumRodenja = datumrodenja;    
          
            
        }

        public int ID1 { get => ID; set => ID = value; }
        public string Ime1 { get => Ime; set => Ime = value; }
        public string Prezime1 { get => Prezime; set => Prezime = value; }
        public string Sektor1 { get => Sektor; set => Sektor = value; }

        public string DatumRodenja1 { get => DatumRodenja; set => DatumRodenja = value; }


    }
}
