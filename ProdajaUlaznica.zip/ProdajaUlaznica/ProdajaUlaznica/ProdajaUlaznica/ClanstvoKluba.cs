﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.IO;
using System.Collections;

namespace ProdajaUlaznica
{
    public partial class ClanstvoKluba : Form
    {

        static List<ClanstvoKorisnik> ListaClanstvaKorisnika = new List<ClanstvoKorisnik>();
        static string pathdocuments = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        static string xmlfile = "ClanstvaKorisnici.xml";
        static string path = Path.Combine(pathdocuments, xmlfile);

        public ClanstvoKluba()
        {


            InitializeComponent();
        }

        private void btnUclani_Click(object sender, EventArgs e)
        {

            ClanstvoKorisnik ClanstvoKorisnika = new ClanstvoKorisnik(Convert.ToInt32(txtBxOIBClan.Text), txtBxImeClan.Text, txtBxPrezimeClan.Text, comBxSpol.Text, Convert.ToString(datumRodenjaClan.Value));
            ListaClanstvaKorisnika.Add(ClanstvoKorisnika);
            DialogResult dialogResult = MessageBox.Show("Želite li učlaniti još jednu osobu?", "Član", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.No)
            {
                try
                {
                    var KorisniciClanstva = XDocument.Load(path);
                    foreach (ClanstvoKorisnik korisnikClanstva in ListaClanstvaKorisnika)
                    {
                        var Korisnik = new XElement("Korisnik",
                            new XElement("ID", korisnikClanstva.ID1),
                            new XElement("Ime", korisnikClanstva.Ime1),
                            new XElement("Prezime", korisnikClanstva.Prezime1),
                        new XElement("Spol", korisnikClanstva.Spol1),
                        new XElement("Datumrodenja", korisnikClanstva.DatumRodenja1));
                        KorisniciClanstva.Root.Add(Korisnik);

                    }
                    KorisniciClanstva.Save(path);
                }
                catch (Exception ex)
                {
                    var KorisniciClanstva = new XDocument();
                    KorisniciClanstva.Add(new XElement("Korisnici"));
                    foreach (ClanstvoKorisnik korisnikClanstva in ListaClanstvaKorisnika)
                    {
                        var Korisnik = new XElement("Korisnik",
                        new XElement("ID", korisnikClanstva.ID1),
                        new XElement("Ime", korisnikClanstva.Ime1),
                        new XElement("Prezime", korisnikClanstva.Prezime1),
                        new XElement("Spol", korisnikClanstva.Spol1),
                        new XElement("Datumrodenja", korisnikClanstva.DatumRodenja1));

                        KorisniciClanstva.Root.Add(Korisnik);
                    }

                    KorisniciClanstva.Save(path);

                }
                ListaClanstvaKorisnika.Clear();
                this.Close();
            }
            txtBxImeClan.Text = "";
            txtBxPrezimeClan.Text = "";
            txtBxOIBClan.Text = "";

        }
    }
}
