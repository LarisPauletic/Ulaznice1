﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProdajaUlaznica
{
    class ClanstvoKorisnik
    {
        int ID;
        string Ime, Prezime, Spol, DatumRodenja;
       

        public ClanstvoKorisnik(int iD, string ime, string prezime, string spol, string datumrodenja)
        {
            ID = iD;
            Ime = ime;
            Prezime = prezime;
            Spol = spol;
            DatumRodenja = datumrodenja;
        
        }

        public int ID1 { get => ID; set => ID = value; }
        public string Ime1 { get => Ime; set => Ime = value; }
        public string Prezime1 { get => Prezime; set => Prezime = value; }
        public string Spol1 { get => Spol; set => Spol = value; }

        public string DatumRodenja1 { get => DatumRodenja; set => DatumRodenja = value; }

    }
}
