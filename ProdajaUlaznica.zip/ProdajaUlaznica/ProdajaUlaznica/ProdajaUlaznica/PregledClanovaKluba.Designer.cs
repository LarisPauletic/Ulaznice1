﻿namespace ProdajaUlaznica
{
    partial class PregledClanovaKluba
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPretraziClanovi = new System.Windows.Forms.Button();
            this.txtBxOibClanPretraga = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.richTxtBxClanovi = new System.Windows.Forms.RichTextBox();
            this.cmBxSpolPretraga = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btnPretraziClanovi
            // 
            this.btnPretraziClanovi.Location = new System.Drawing.Point(513, 370);
            this.btnPretraziClanovi.Name = "btnPretraziClanovi";
            this.btnPretraziClanovi.Size = new System.Drawing.Size(177, 88);
            this.btnPretraziClanovi.TabIndex = 11;
            this.btnPretraziClanovi.Text = "Pretraži";
            this.btnPretraziClanovi.UseVisualStyleBackColor = true;
            // 
            // txtBxOibClanPretraga
            // 
            this.txtBxOibClanPretraga.Location = new System.Drawing.Point(249, 377);
            this.txtBxOibClanPretraga.Name = "txtBxOibClanPretraga";
            this.txtBxOibClanPretraga.Size = new System.Drawing.Size(145, 22);
            this.txtBxOibClanPretraga.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(128, 441);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "Spol";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(128, 377);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "OIB";
            // 
            // richTxtBxClanovi
            // 
            this.richTxtBxClanovi.Location = new System.Drawing.Point(155, 12);
            this.richTxtBxClanovi.Name = "richTxtBxClanovi";
            this.richTxtBxClanovi.Size = new System.Drawing.Size(455, 341);
            this.richTxtBxClanovi.TabIndex = 6;
            this.richTxtBxClanovi.Text = "";
            // 
            // cmBxSpolPretraga
            // 
            this.cmBxSpolPretraga.FormattingEnabled = true;
            this.cmBxSpolPretraga.Location = new System.Drawing.Point(249, 432);
            this.cmBxSpolPretraga.Name = "cmBxSpolPretraga";
            this.cmBxSpolPretraga.Size = new System.Drawing.Size(145, 24);
            this.cmBxSpolPretraga.TabIndex = 12;
            // 
            // PregledClanovaKluba
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 531);
            this.Controls.Add(this.cmBxSpolPretraga);
            this.Controls.Add(this.btnPretraziClanovi);
            this.Controls.Add(this.txtBxOibClanPretraga);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.richTxtBxClanovi);
            this.Name = "PregledClanovaKluba";
            this.Text = "PregledClanovaKluba";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPretraziClanovi;
        private System.Windows.Forms.TextBox txtBxOibClanPretraga;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTxtBxClanovi;
        private System.Windows.Forms.ComboBox cmBxSpolPretraga;
    }
}